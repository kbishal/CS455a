- install.sh script is used to set up the first vm where applictin code is available
- install2.sh is used to set up the databases in the second vm.

NOTE :- 
For the database vm we also need to change the host ip to 0.0.0.0, so that we can access it using the machine's ip address.
