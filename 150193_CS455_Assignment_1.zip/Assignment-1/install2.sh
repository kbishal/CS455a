sudo apt install mysql-server
mysql -u root -p < sqlquery.sql
